from .device import (TorchDeviceInfo, get_avail_devices_info,
                     get_cpu_device_info)
from .dtype import get_np_dtype_from_torch