from .module import init_and_load
from .MultiModule import MultiModule